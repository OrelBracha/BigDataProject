const express = require("express");
const router = express.Router();
const trainController = require("../controllers/traincontroller.cjs");

router
    .route("/trainModel")
    .post(trainController.trainModel);
router
    .route('/addToSalesFromKafka')
    .post(trainController.addToSalesFromKafka);
router
    .route('/addToSalesFromKafka')
    .post(trainController.addToSalesFromKafka);

module.exports = router;