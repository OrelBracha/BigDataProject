const mongoose = require('mongoose');
const path = ''+ __dirname;

const storeDetailsSchema = require('../schema/storedetailsschema.cjs');
const saleDetailsSchema = require('../schema/saledetailsschema.cjs');




mongoose.connect(`mongodb://localhost:27017/test`, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});
const db = mongoose.connection;

db.on("error", console.error.bind(console, "connection error:"));
db.once("open", () => {
    console.log("connected to DB!");
});

exports.addToStore = () => {
    const name = "String";
    const city = "String";
    const owner_details = "String";
    const vanila_stock = 0;
    const chocolate_stock = 0;
    const lemon_stock = 0;
    const strawberry_stock = 0;
    const halva_stock = 0;
    const storeToAdd = new storeDetailsSchema({
        name: name,
        city: city,
        owner_details: owner_details,
        vanila_stock: vanila_stock,
        chocolate_stock: chocolate_stock,
        lemon_stock: lemon_stock,
        strawberry_stock: strawberry_stock,
        halva_stock: halva_stock
    });

    storeToAdd.save().then(() => {
        console.log("storew saved");
    });
}

exports.addToSale = (data) => {
    return new Promise((resolve, reject) => {
        try {
            const flavor = data.flavor;
            // const date = new Date(data.date);
            const date = new Date();
            const name = data.name;
            const weight = data.weight;
            const foundSale = saleDetailsSchema.findOne({ 'name': name });
            if (foundSale) {
                if (foundSale.date == date && foundSale.flavor == flavor) {
                    foundSale.weight = foundSale.weight + weight;
                    foundSale.save(function (err) {
                        if (!err) {
                            console.log("sale updated");
                        }
                        else {
                            console.log("Error!");
                        }
                    });
                    resolve();
                }
            }
            const saleToAdd = new saleDetailsSchema({
                flavor: flavor,
                date: date,
                weight: weight,
                name: name
            });

            saleToAdd.save().then(() => {
                console.log("sale saved");
                resolve();
            });
        } catch (error) {
            resolve(-1);
        }
    })
}
