const bigml = require('bigml');
const connection = new bigml.BigML("jbareenjeme", "fac28f782eb5420086e3386246b32daff778fc9d");

exports.createLocalModelFromCsvFile = (filePath) => {
    const source = new bigml.Source(connection);
    source.create(filePath, function (error, sourceInfo) {
        if (!error && sourceInfo) {
            var dataset = new bigml.Dataset();
            dataset.create(sourceInfo, function (error, datasetInfo) {
                if (!error && datasetInfo) {
                    var model = new bigml.Model();
                    model.create(datasetInfo, function (error, modelInfo) {
                        if (!error && modelInfo) {
                            var prediction = new bigml.Prediction();
                            prediction.create(modelInfo, {
                                DAY:1,MONTH:1,SEASON:1,holiday:1,WEATHER:1,SIZE:1,TYPE:1,TODDLERS:1,CHILDREN:1,GRADUETES:1,
                                ADULTS:1,RESISTANCE:1,GOLD:1,VANILA:1,CHOCOLATE:1,LEMON:1,STRAWBERRY:1,HALVA:1
                            })
                        }
                    });
                }
            });
        }
    });
}

exports.getSource = (sourceName) => {
    const source = new bigml.Source(connection);
    source.get(sourceName, function (error, resource) {
        if (!error && resource) {
          console.log(resource);
        }
      })
}

exports.predictFromLocalModel = (modelName, prediction) => {
    const localModel = new bigml.LocalModel(modelName);
    localModel.predict(prediction,
        function (error, prediction) { console.log(prediction); });
}
