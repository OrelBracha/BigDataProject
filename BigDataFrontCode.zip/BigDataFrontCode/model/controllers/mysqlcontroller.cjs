const mysql = require('mysql2');
const bigmlController = require('../controllers/bigmlcontroller.cjs');


const mySqlConnection = mysql.createConnection({
    host: "localhost",
    port: 3306,
    user: "root",
    database: "mydb"
});

exports.handleSqlQuery = async (sql, flavor, callback) => {
    return new Promise(async (resolve, reject) => {
        try {
            mySqlConnection.connect(async function (err) {
                if (err) throw err;
                console.log("Connected! 1111");
                mySqlConnection.query(sql, async (error, results, fields) => {
                    console.log("mySqlConnection query results: ", results);
                    if (error) {
                        return console.error(error.message);
                    }
                    if (results.length > 0) {

                        console.log("wait for callback");
                        let callBackResult = await callback(results, flavor);
                        console.log("callback: ", callBackResult);
                        resolve(callBackResult);

                    } else {
                        reject(-1);
                    }
                });
            });
        } catch (error) {
            reject(-1);
        }
    })
}


exports.mySqlConnection = () => {
    return mySqlConnection;
}

exports.selectFrom = (query) => {
    let combinedData = {};
    mySqlConnection.connect(function (err) {
        if (err) throw err;
        console.log("Connected!");
        mySqlConnection.query(query, (error, results, fields) => {
            if (error) {
                return console.error(error.message);
            }
            console.log(results);
            results = results[0];
            combinedData['settelmentName'] = results.SETTLEMENT_NAME;
            combinedData['settelmentSize'] = results.SIZE;
            combinedData['settelmentType'] = results.TYPE;
            combinedData['settelmentToddlers'] = results.TODDLERS;
            combinedData['settelmentChildren'] = results.CHILDREN;
            combinedData['settelmentGraduets'] = results.GRADUETES;
            combinedData['settelmentAdults'] = results.ADULTS;
            combinedData['settelmentResistance'] = results.RESISTANCE;
            combinedData['settelmentGold'] = results.GOLD;
            console.log(combinedData);
            bigmlController.predictFromLocalModel("model/63556bb2969fe90b6b003fe0", combinedData);
        });
    });
}

exports.executeQuery = (query) => {
    return new Promise((resolve, reject) => {
        console.log("executeQuery");
        mySqlConnection.connect(function (err) {
            if (err) throw err;
            console.log("Connected!");
            mySqlConnection.query(query, (error, results, fields) => {
                if (error) {
                    reject(console.error(error.message));
                }
                resolve(results);
            });
        });
    })
}


exports.createTable = (tableName, parameters) => {
    const sql = `CREATE TABLE ${tableName} (${parameters})`;
    this.executeQuery(sql);
}

exports.insertToTable = (tableName, parameters, values) => {
    const sql = `INSERT INTO ${tableName} (${parameters}) VALUES (${values})`;
    this.executeQuery(sql);
}
