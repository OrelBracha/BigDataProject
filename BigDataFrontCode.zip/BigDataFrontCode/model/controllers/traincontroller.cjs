const mysqlcontroller = require('../controllers/mysqlcontroller.cjs');
const mongodbcontroller = require('../controllers/mongodbcontroller.cjs');
const combinedbcontroller = require('../controllers/combinedcontroller.cjs');
const axios = require('axios');
const vanilaData = require('../data/vanila.cjs');
const chocloateData = require('../data/chocolate.cjs');
const halvaData = require('../data/halva.cjs');
const lemonData = require('../data/lemon.cjs');
const strawberryData = require('../data/strawberry.cjs');


getSeason = (date) => {
    month = date.getMonth() + 1;
    return (month % 12) / 3.;
}

dateFormater = (date) => {
    let dayFormat = date.getDate();
    if (dayFormat < 10) {
        dayFormat = "0" + dayFormat;
    }
    let monthFormat = date.getMonth() + 1;
    if (monthFormat < 10) {
        monthFormat = "0" + dayFormat;
    }
    const yearFormat = date.getFullYear();
    const dateFormat = "" + yearFormat + "-" + monthFormat + "-" + dayFormat;
    return dateFormat;
}

getHoliday = (date) => {
    return new Promise(async (resolve, reject) => {
        const dayFormat = dateFormater(date);
        const response = await axios.get(`https://www.hebcal.com/converter?cfg=json&date=${dayFormat}&g2h=1&strict=1`);
        if (response) {
            if (response.data.events.length > 1) {
                resolve(1);
            }
            resolve(-1);
        };
    })
}


getWeather = async (date, town = "") => {

    let weather = getSeason(date);
    if (weather == 3) {
        return 1;
    }
    return weather;
}


async function testCallback(results, flavor) {
    results = results[0];
    combinedData = {};
    combinedData['size'] = results.SIZE;
    combinedData['type'] = results.TYPE;
    combinedData['toddlers'] = results.TODDLERS;
    combinedData['children'] = results.CHILDREN;
    combinedData['graduates'] = results.GRADUETES;
    combinedData['adults'] = results.ADULTS;
    combinedData['resistance'] = results.RESISTANCE;
    combinedData['gold'] = results.GOLD;
    combinedData['season'] = await getSeason(new Date());
    combinedData['holiday'] = await getHoliday(new Date());
    combinedData['month'] = 4;
    combinedData['day'] = 4;
    combinedData['weather'] = await getWeather(new Date(), 'tel aviv');
    if (flavor == 'Vanilla') {
        return vanilaData.predictVanila(combinedData);
    } else if (flavor == 'Chocolate') {
        return chocloateData.predictChocolate(combinedData);
    } else if (flavor == 'Halva') {
        return halvaData.predictHalva(combinedData);
    } else if (flavor == 'Lemon') {
        return lemonData.predictLemon(combinedData);
    } else if (flavor == 'Strawberry') {
        return strawberryData.predictStrawberry(combinedData);
    }
    return -1;
}

exports.addToSalesFromKafka = async (req, res) => {
    try {
        await mongodbcontroller.addToSale(req.body);
        const resCombined = await combinedbcontroller.addToCombinedDetails(req.body, getHoliday, getWeather, getSeason);
        console.log("resCombined: ", resCombined);
    } catch (error) {
        console.log(error);
    }
}

exports.trainModel = async (req, res) => {
    const { store, flavor, date } = req.body;
    console.log(store, flavor, date)
    let predictedValue = 0;
    if (!store || !flavor || !date) {
        res.send({ "ok": false });
        return;
    }
    console.log("test trainModel");
    console.log(store, flavor, date);
    try {
        const sql = `SELECT * FROM settlements WHERE SETTLEMENT_NAME IN ('${store}');`;
        try {
            predictedValue = await mysqlcontroller.handleSqlQuery(sql, flavor, testCallback);
            predictedValue = predictedValue / 50;
        } catch (error) {
            res.send({ "ok": false });
            return;
        }
        if (predictedValue == -1) {
            res.send({ "ok": false });
            return;
        }
        if (predictedValue < 1) {
            res.send({ "ok": true, "resultValues": { "predictedValue": predictedValue, "type": 'אפסית' } });
        } else if (predictedValue < 20) {
            res.send({ "ok": true, "resultValues": { "predictedValue": predictedValue, "type": 'מועטה' } });
        } else if (predictedValue < 60) {
            res.send({ "ok": true, "resultValues": { "predictedValue": predictedValue, "type": 'בינונית' } });
        } else if (predictedValue < 120) {
            res.send({ "ok": true, "resultValues": { "predictedValue": predictedValue, "type": 'גבוהה' } });
        } else {
            res.send({ "ok": true, "resultValues": { "predictedValue": predictedValue, "type": 'גבוהה מאוד' } });
        }
    } catch (err) {
        res.send({ ok: false, message: "Error!" });
    }
}
