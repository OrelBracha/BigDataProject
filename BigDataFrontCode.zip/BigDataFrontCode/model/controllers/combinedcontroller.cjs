const mongoose = require('mongoose');
const axios = require('axios');
const path = ''+ __dirname;


const combinedDetailsSchema = require('../schema/storedetailsschema.cjs');
const salesDetailsSchema = require('../schema/saledetailsschema.cjs');
const mysqlController = require('../controllers/mysqlcontroller.cjs')

// const combinedDetailsSchema = require('/home/mohamadj/Desktop/BigData/model/schema/storedetailsschema.cjs');
// const salesDetailsSchema = require(path + 'schema/saledetailsschema.cjs');
// const mysqlController = require('/home/mohamadj/Desktop/BigData/model/controllers/mysqlcontroller.cjs')

mongoose.connect(`mongodb://localhost:27017/test`, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});
const db = mongoose.connection;

db.on("error", console.error.bind(console, "connection error:"));
db.once("open", () => {
    console.log("connected to DB!");
});

exports.addToCombinedDetails = (data, getHoliday, getWeather, getSeason) => {
    return new Promise(async (resolve, reject) => {
        // console.log("addToCombinedDetails data: ", data);
        try {
            const name = data.name;
            const branchName = 'TLV'
            const sql = `SELECT * FROM settlements WHERE SETTLEMENT_NAME IN ('${branchName}');`;
            // const date = new Date(data.date);
            const date = new Date();
            const day = date.getDate();
            const month = date.getMonth() + 1;

            console.log("addToCombinedDetails month: ", month);
            const filter = { 'settelmentName': name, "day": day, "month": month };
            let updateCombined = { 'vanilConsumption': 0 };
            const settelmentData = await mysqlController.executeQuery(sql);
            console.log("addToCombinedDetails settelmentData: ", settelmentData);
            let foundSellsDetails = salesDetailsSchema.findOne({ 'name': name });
            if(foundSellsDetails && foundSellsDetails.flavor == data.flavor && foundSellsDetails.date == date){
                switch (data.flavor) {
                    case 'Strawaberry':
                        updateCombined = { 'strowberryConsumption': foundSellsDetails.weight + data.weight };
                        break;
                    case 'Chocollate':
                        updateCombined = { 'choclateConsumption': foundSellsDetails.weight + data.weight };
                        break;
                    case 'Lemon':
                        updateCombined = { 'lemonConsumption': foundSellsDetails.weight + data.weight };
                        break;
                    case 'Halva':
                        updateCombined = { 'halvaConsumption': foundSellsDetails.weight + data.weight };
                        break;
                    default:
                        updateCombined = { 'vanilConsumption': foundSellsDetails.weight + data.weight };
                        break;
                }
                console.log("addToCombinedDetails updateCombined: ", updateCombined);
            }
            if(settelmentData.length == 0){
                console.log('settelmentData not found!');
                reject(-1);
            }
            console.log("addToCombinedDetails updateCombined: ", updateCombined);
            // let foundCombined = await combinedDetailsSchema.findOneAndUpdate(filter, updateCombined);
            let foundCombined = salesDetailsSchema.findOne({ 'name': name });
            if(foundCombined.flavor == data.flavor && foundCombined.day == day && foundCombined.name == name){
                foundCombined.weight = data.weight;
                resolve(0);
            }
            else {
                console.log("foundCombined not found");
                console.log({
                    settelmentName: settelmentData[0].SETTLEMENT_NAME,
                    settelmentSize: settelmentData[0].SIZE,
                    settelmentType: settelmentData[0].TYPE,
                    settelmentToddlers: settelmentData[0].TODDLERS,
                    settelmentChildren: settelmentData[0].CHILDREN,
                    settelmentGraduets: settelmentData[0].GRADUETES,
                    settelmentAdults: settelmentData[0].ADULTS,
                    settelmentResistance: settelmentData[0].RESISTANCE,
                    settelmentGold: settelmentData[0].GOLD,
                    day: day,
                    month: month,
                    season: getSeason(date),
                    holiday: await getHoliday(date),
                    weather: getWeather(date),
                    vanilConsumption: 0,
                    choclateConsumption: 0,
                    strowberryConsumption: 0,
                    lemonConsumption: 0,
                    halvaConsumption: 0
                });
                const combinedDataToAdd = new combinedDetailsSchema({
                    settelmentName: settelmentData[0].SETTLEMENT_NAME,
                    settelmentSize: settelmentData[0].SIZE,
                    settelmentType: settelmentData[0].TYPE,
                    settelmentToddlers: settelmentData[0].TODDLERS,
                    settelmentChildren: settelmentData[0].CHILDREN,
                    settelmentGraduets: settelmentData[0].GRADUETES,
                    settelmentAdults: settelmentData[0].ADULTS,
                    settelmentResistance: settelmentData[0].RESISTANCE,
                    settelmentGold: settelmentData[0].GOLD,
                    day: day,
                    month: month,
                    season: getSeason(date),
                    holiday: await getHoliday(date),
                    weather: getWeather(date),
                    vanilConsumption: 0,
                    choclateConsumption: 0,
                    strowberryConsumption: 0,
                    lemonConsumption: 0,
                    halvaConsumption: 0
                });
                console.log("Trying to add to combinedDataToAdd");
                combinedDataToAdd.save().then(() => {
                    console.log("combinedDataToAdd saved");
                    resolve(1);
                });
            }
            // resolve();
        } catch (error) {
            console.log("not found");
            reject(-1);
        }
    })
}
