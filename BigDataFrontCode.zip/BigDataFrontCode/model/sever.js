const express = require('express');
const app = express();
const path = require('path');
const fetch = require('cross-fetch');

const localPath = ''+ __dirname+'/';


const uuid = require("uuid");
const Kafka = require("node-rdkafka");

const kafkaConf = {
  "group.id": "sales_simulator",
  "metadata.broker.list": "dory-01.srvs.cloudkafka.com:9094,dory-02.srvs.cloudkafka.com:9094,dory-03.srvs.cloudkafka.com:9094".split(","),
  "socket.keepalive.enable": true,
  "security.protocol": "SASL_SSL",
  "sasl.mechanisms": "SCRAM-SHA-256",
  "sasl.username": "hgb4fnaz",
  "sasl.password": "Oxr0HbiA7QpKW1zAtq-W6lSJ04IwfTaW",
  "debug": "generic,broker,security"
};

const prefix = "hgb4fnaz-";
const topic = `${prefix}default`;
const producer = new Kafka.Producer(kafkaConf);

const genMessage = m => new Buffer.alloc(m.length,m);

const topics = [topic];
const consumer = new Kafka.KafkaConsumer(kafkaConf, {
  "auto.offset.reset": "beginning"
});

consumer.on("error", function(err) {
    console.error(err);
  });
  consumer.on("ready", function(arg) {
    console.log(`Consumer ${arg.name} ready`);
    consumer.subscribe(topics);
    consumer.consume();
    console.log("I consumed");
  });
  
  consumer.on("data", function(m) {
    const message = m.value.toString();
   if(message.includes("weight")){
        let copyMessage = message;
        copyMessage = copyMessage.substring(1, copyMessage.length - 1).replaceAll("'", "\"")
        let obj = JSON.parse(copyMessage);
        var apiUrl = 'http://localhost:3000/train/addToSalesFromKafka';
        try {
            fetch(apiUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(obj),
            })
                .then((response) => response.json())
                .then((data) => {
                    if (data.ok) {
                     console.log('Success:', data);
                    }else{
                     console.log("failed!");
                    }
                })
                .catch((error) => {
                    console.error('Error:', error);
                });
        } catch (error) {
            console.log("Error!")
        }
    }
  });

  consumer.on("disconnected", function(arg) {
    process.exit();
  });
  consumer.on('event.error', function(err) {
    console.error(err);
    process.exit(1);
  });
  consumer.on('event.log', function(log) {
    console.log(log);
  });
  consumer.connect();

const trainRouter = require(localPath + "/routes/trainroute.cjs");

app.use(express.json());


app.use("/train", trainRouter);

app.get('/css/sb-admin-2.min.css', function(req, res) {
    res.sendFile(path.join(localPath + "../css/sb-admin-2.min.css"));
});

app.get('/css/hebcal-styles.css', function(req, res) {
    res.sendFile(path.join(localPath + "../css/hebcal-styles.css"));
  });

app.get('/', (req, res) => {
    res.sendFile(path.join(localPath + '../Dashboard-Inventory.html'));
})

app.get('/stores.html', (req, res) => {
    res.sendFile(path.join(localPath + '../stores.html'));
})
app.get('/model.html', (req, res) => {
    res.sendFile(path.join(localPath + '../model.html'));
})

app.get('/*', (req, res) => {
  res.sendFile(path.join(localPath + '../Dashboard-Inventory.html'));
})

app.listen(process.env.port || 3000);

console.log('Running at Port 3000');
