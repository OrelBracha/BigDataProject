const mongoose = require("mongoose");

const combinedDetailsSchema = new mongoose.Schema({
    settelmentName: String,
    settelmentSize: Number,
    settelmentType: Number,
    settelmentToddlers: Number,
    settelmentChildren: Number,
    settelmentGraduets: Number,
    settelmentAdults: Number,
    settelmentResistance: Number,
    settelmentGold: Number,
    day: Number,
    month: Number,
    season: Number,
    holiday: Number,
    weather: Number,
    vanilConsumption: Number,
    choclateConsumption: Number,
    strowberryConsumption: Number,
    lemonConsumption: Number,
    halvaConsumption: Number
});

const CombinedDetailsSchema = mongoose.model("combinedDetailsSchema", combinedDetailsSchema);
module.exports = CombinedDetailsSchema;
