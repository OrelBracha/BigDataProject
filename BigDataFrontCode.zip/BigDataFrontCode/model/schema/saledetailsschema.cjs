const mongoose = require("mongoose");

const saleDetailsSchema = new mongoose.Schema({
    flavor: String,
    date: Date,
    weight: Number,
    name: String
});

const SaleDetailsSchema = mongoose.model("saleDetailsSchema", saleDetailsSchema);
module.exports = SaleDetailsSchema;
