const mongoose = require("mongoose");

const storeDetailsSchema = new mongoose.Schema({
    name: String,
    city: String,
    owner_details: String,
    vanila_stock: Number,
    chocolate_stock: Number,
    lemon_stock: Number,
    strawberry_stock: Number,
    halva_stock: Number
});

const StoreDetailsSchema = mongoose.model("storeDetailsSchema", storeDetailsSchema);
module.exports = StoreDetailsSchema;
