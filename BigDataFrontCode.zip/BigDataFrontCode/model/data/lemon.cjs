
/**
*  Predictor for LEMON from model/63562d27aba2df25350020b4
*  Predictive model by BigML - Machine Learning Made Easy
*/
exports.predictLemon = (data) => {
    if (data.season == null) {
        return 291.9238;
    }
    else if (data.season > 1) {
        if (data.holiday == null) {
            return 498.2051;
        }
        else if (data.holiday=="0") {
            if (data.toddlers == null) {
                return 358.65315;
            }
            else if (data.toddlers > 11) {
                if (data.size == null) {
                    return 434.68986;
                }
                else if (data.size > 6) {
                    return 833.42022;
                }
                else if (data.size <= 6) {
                    if (data.adults == null) {
                        return 417.57265;
                    }
                    else if (data.adults > 14) {
                        return 972.29766;
                    }
                    else if (data.adults <= 14) {
                        if (data.graduetes == null) {
                            return 409.03842;
                        }
                        else if (data.graduetes > 51) {
                            return 1663.2;
                        }
                        else if (data.graduetes <= 51) {
                            if (data.graduetes > 31) {
                                if (data.children == null) {
                                    return 428.15469;
                                }
                                else if (data.children > 25) {
                                    if (data.graduetes > 45) {
                                        return 1352.48438;
                                    }
                                    else if (data.graduetes <= 45) {
                                        if (data.toddlers > 25) {
                                            return 78.62469;
                                        }
                                        else if (data.toddlers <= 25) {
                                            if (data.toddlers > 24) {
                                                return 2027.4;
                                            }
                                            else if (data.toddlers <= 24) {
                                                if (data.graduetes > 35) {
                                                    if (data.adults > 7) {
                                                        return 815.45954;
                                                    }
                                                    else if (data.adults <= 7) {
                                                        return 454.2628;
                                                    }
                                                }
                                                else if (data.graduetes <= 35) {
                                                    if (data.toddlers > 14) {
                                                        if (data.graduetes > 34) {
                                                            return 265.62978;
                                                        }
                                                        else if (data.graduetes <= 34) {
                                                            return 660.85395;
                                                        }
                                                    }
                                                    else if (data.toddlers <= 14) {
                                                        return 314.54094;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                else if (data.children <= 25) {
                                    return 328.78827;
                                }
                            }
                            else if (data.graduetes <= 31) {
                                if (data.gold == null) {
                                    return 264.18508;
                                }
                                else if (data.gold > 18) {
                                    return 861.4026;
                                }
                                else if (data.gold <= 18) {
                                    if (data.toddlers > 28) {
                                        return 1083.63281;
                                    }
                                    else if (data.toddlers <= 28) {
                                        return 210.89732;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            else if (data.toddlers <= 11) {
                if (data.size == null) {
                    return 328.99955;
                }
                else if (data.size > 0) {
                    if (data.resistance == null) {
                        return 366.26086;
                    }
                    else if (data.resistance > 10) {
                        return 254.11853;
                    }
                    else if (data.resistance <= 10) {
                        if (data.gold == null) {
                            return 388.92479;
                        }
                        else if (data.gold > 23) {
                            return 114.39375;
                        }
                        else if (data.gold <= 23) {
                            if (data.type == null) {
                                return 396.32455;
                            }
                            else if (data.type > 1) {
                                if (data.graduetes == null) {
                                    return 441.06448;
                                }
                                else if (data.graduetes > 40) {
                                    return 953.1;
                                }
                                else if (data.graduetes <= 40) {
                                    if (data.toddlers > 6) {
                                        if (data.gold > 22) {
                                            return 1278.7125;
                                        }
                                        else if (data.gold <= 22) {
                                            if (data.children == null) {
                                                return 383.81187;
                                            }
                                            else if (data.children > 24) {
                                                if (data.resistance > 9) {
                                                    return 1774.8;
                                                }
                                                else if (data.resistance <= 9) {
                                                    if (data.toddlers > 9) {
                                                        return 654.49438;
                                                    }
                                                    else if (data.toddlers <= 9) {
                                                        if (data.toddlers > 7) {
                                                            return 209.18347;
                                                        }
                                                        else if (data.toddlers <= 7) {
                                                            return 644.55221;
                                                        }
                                                    }
                                                }
                                            }
                                            else if (data.children <= 24) {
                                                return 319.10361;
                                            }
                                        }
                                    }
                                    else if (data.toddlers <= 6) {
                                        return 639.5994;
                                    }
                                }
                            }
                            else if (data.type <= 1) {
                                if (data.size > 3) {
                                    if (data.toddlers > 7) {
                                        if (data.size > 6) {
                                            if (data.adults == null) {
                                                return 668.0413;
                                            }
                                            else if (data.adults > 11) {
                                                return 455.87647;
                                            }
                                            else if (data.adults <= 11) {
                                                if (data.graduetes == null) {
                                                    return 1269.175;
                                                }
                                                else if (data.graduetes > 33) {
                                                    return 1892.775;
                                                }
                                                else if (data.graduetes <= 33) {
                                                    return 21.975;
                                                }
                                            }
                                        }
                                        else if (data.size <= 6) {
                                            return 412.09836;
                                        }
                                    }
                                    else if (data.toddlers <= 7) {
                                        return 201.36667;
                                    }
                                }
                                else if (data.size <= 3) {
                                    if (data.gold > 16) {
                                        return 554.35179;
                                    }
                                    else if (data.gold <= 16) {
                                        return 211.45615;
                                    }
                                }
                            }
                        }
                    }
                }
                else if (data.size <= 0) {
                    if (data.gold == null) {
                        return 300.60408;
                    }
                    else if (data.gold > 16) {
                        if (data.adults == null) {
                            return 246.27243;
                        }
                        else if (data.adults > 16) {
                            return 436.34902;
                        }
                        else if (data.adults <= 16) {
                            return 231.50919;
                        }
                    }
                    else if (data.gold <= 16) {
                        if (data.graduetes == null) {
                            return 332.42896;
                        }
                        else if (data.graduetes > 36) {
                            if (data.gold > 10) {
                                return 319.57496;
                            }
                            else if (data.gold <= 10) {
                                return 534.36097;
                            }
                        }
                        else if (data.graduetes <= 36) {
                            if (data.gold > 15) {
                                return 472.06667;
                            }
                            else if (data.gold <= 15) {
                                if (data.weather == null) {
                                    return 287.68996;
                                }
                                else if (data.weather > 1) {
                                    return 347.6644;
                                }
                                else if (data.weather <= 1) {
                                    if (data.graduetes > 27) {
                                        if (data.graduetes > 35) {
                                            return 456.44773;
                                        }
                                        else if (data.graduetes <= 35) {
                                            return 206.37183;
                                        }
                                    }
                                    else if (data.graduetes <= 27) {
                                        return 652.21875;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        else if (data.holiday=="1") {
            if (data.size == null) {
                return 807.57326;
            }
            else if (data.size > 6) {
                return 2076.26528;
            }
            else if (data.size <= 6) {
                if (data.weather == null) {
                    return 753.79824;
                }
                else if (data.weather > 1) {
                    if (data.resistance == null) {
                        return 815.23722;
                    }
                    else if (data.resistance > 17) {
                        if (data.gold == null) {
                            return 1857.7875;
                        }
                        else if (data.gold > 3) {
                            return 3101.79375;
                        }
                        else if (data.gold <= 3) {
                            return 613.78125;
                        }
                    }
                    else if (data.resistance <= 17) {
                        if (data.toddlers == null) {
                            return 804.23405;
                        }
                        else if (data.toddlers > 12) {
                            if (data.toddlers > 18) {
                                return 575.01563;
                            }
                            else if (data.toddlers <= 18) {
                                if (data.adults == null) {
                                    return 1183.635;
                                }
                                else if (data.adults > 5) {
                                    return 1068.3931;
                                }
                                else if (data.adults <= 5) {
                                    return 1891.54955;
                                }
                            }
                        }
                        else if (data.toddlers <= 12) {
                            if (data.toddlers > 6) {
                                if (data.gold == null) {
                                    return 713.89829;
                                }
                                else if (data.gold > 8) {
                                    if (data.children == null) {
                                        return 804.42349;
                                    }
                                    else if (data.children > 22) {
                                        if (data.adults == null) {
                                            return 1000.44807;
                                        }
                                        else if (data.adults > 20) {
                                            return 2895.84375;
                                        }
                                        else if (data.adults <= 20) {
                                            if (data.size > 2) {
                                                if (data.graduetes == null) {
                                                    return 1632.72188;
                                                }
                                                else if (data.graduetes > 31) {
                                                    return 2198.02313;
                                                }
                                                else if (data.graduetes <= 31) {
                                                    return 219.46875;
                                                }
                                            }
                                            else if (data.size <= 2) {
                                                if (data.gold > 10) {
                                                    if (data.toddlers > 7) {
                                                        return 880.6154;
                                                    }
                                                    else if (data.toddlers <= 7) {
                                                        return 1538.5321;
                                                    }
                                                }
                                                else if (data.gold <= 10) {
                                                    return 519.96375;
                                                }
                                            }
                                        }
                                    }
                                    else if (data.children <= 22) {
                                        if (data.toddlers > 7) {
                                            if (data.adults == null) {
                                                return 760.60988;
                                            }
                                            else if (data.adults > 9) {
                                                if (data.graduetes == null) {
                                                    return 827.87248;
                                                }
                                                else if (data.graduetes > 36) {
                                                    return 1165.14024;
                                                }
                                                else if (data.graduetes <= 36) {
                                                    if (data.graduetes > 30) {
                                                        if (data.toddlers > 9) {
                                                            return 850.25556;
                                                        }
                                                        else if (data.toddlers <= 9) {
                                                            return 500.76094;
                                                        }
                                                    }
                                                    else if (data.graduetes <= 30) {
                                                        return 1171.48341;
                                                    }
                                                }
                                            }
                                            else if (data.adults <= 9) {
                                                return 267.35078;
                                            }
                                        }
                                        else if (data.toddlers <= 7) {
                                            return 326.40043;
                                        }
                                    }
                                }
                                else if (data.gold <= 8) {
                                    if (data.adults == null) {
                                        return 446.37607;
                                    }
                                    else if (data.adults > 14) {
                                        return 130.47094;
                                    }
                                    else if (data.adults <= 14) {
                                        if (data.children == null) {
                                            return 501.79803;
                                        }
                                        else if (data.children > 34) {
                                            return 807.5692;
                                        }
                                        else if (data.children <= 34) {
                                            return 458.99006;
                                        }
                                    }
                                }
                            }
                            else if (data.toddlers <= 6) {
                                return 1031.73445;
                            }
                        }
                    }
                }
                else if (data.weather <= 1) {
                    if (data.gold == null) {
                        return 661.156;
                    }
                    else if (data.gold > 34) {
                        return 2699.2;
                    }
                    else if (data.gold <= 34) {
                        if (data.month == null) {
                            return 653.10049;
                        }
                        else if (data.month > 9) {
                            return 930.02614;
                        }
                        else if (data.month <= 9) {
                            if (data.adults == null) {
                                return 594.80036;
                            }
                            else if (data.adults > 7) {
                                if (data.gold > 17) {
                                    if (data.graduetes == null) {
                                        return 390.15985;
                                    }
                                    else if (data.graduetes > 36) {
                                        if (data.resistance == null) {
                                            return 933.2375;
                                        }
                                        else if (data.resistance > 9) {
                                            return 1489.7125;
                                        }
                                        else if (data.resistance <= 9) {
                                            return 376.7625;
                                        }
                                    }
                                    else if (data.graduetes <= 36) {
                                        if (data.toddlers == null) {
                                            return 315.25259;
                                        }
                                        else if (data.toddlers > 7) {
                                            return 399.57045;
                                        }
                                        else if (data.toddlers <= 7) {
                                            return 50.25357;
                                        }
                                    }
                                }
                                else if (data.gold <= 17) {
                                    if (data.size > 4) {
                                        return 1084.23269;
                                    }
                                    else if (data.size <= 4) {
                                        if (data.gold > 12) {
                                            if (data.size > 0) {
                                                if (data.gold > 16) {
                                                    return 1066;
                                                }
                                                else if (data.gold <= 16) {
                                                    return 255.36;
                                                }
                                            }
                                            else if (data.size <= 0) {
                                                return 941.34942;
                                            }
                                        }
                                        else if (data.gold <= 12) {
                                            if (data.resistance == null) {
                                                return 545.25348;
                                            }
                                            else if (data.resistance > 13) {
                                                return 72.35833;
                                            }
                                            else if (data.resistance <= 13) {
                                                if (data.graduetes == null) {
                                                    return 563.92039;
                                                }
                                                else if (data.graduetes > 43) {
                                                    return 226.375;
                                                }
                                                else if (data.graduetes <= 43) {
                                                    if (data.graduetes > 42) {
                                                        return 1789.425;
                                                    }
                                                    else if (data.graduetes <= 42) {
                                                        if (data.resistance > 6) {
                                                            return 479.92756;
                                                        }
                                                        else if (data.resistance <= 6) {
                                                            return 684.49919;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            else if (data.adults <= 7) {
                                return 313.94224;
                            }
                        }
                    }
                }
            }
        }
    }
    else if (data.season <= 1) {
        if (data.weather == null) {
            return 116.519;
        }
        else if (data.weather > 0) {
            if (data.holiday == null) {
                return 247.01538;
            }
            else if (data.holiday=="0") {
                return 143.62713;
            }
            else if (data.holiday=="1") {
                if (data.size == null) {
                    return 347.73801;
                }
                else if (data.size > 4) {
                    if (data.resistance == null) {
                        return 561.62545;
                    }
                    else if (data.resistance > 8) {
                        return 365.49141;
                    }
                    else if (data.resistance <= 8) {
                        return 823.1375;
                    }
                }
                else if (data.size <= 4) {
                    if (data.toddlers == null) {
                        return 323.14315;
                    }
                    else if (data.toddlers > 8) {
                        if (data.graduetes == null) {
                            return 357.03236;
                        }
                        else if (data.graduetes > 21) {
                            if (data.size > 0) {
                                if (data.toddlers > 22) {
                                    return 113.325;
                                }
                                else if (data.toddlers <= 22) {
                                    if (data.graduetes > 33) {
                                        if (data.toddlers > 20) {
                                            return 781.7;
                                        }
                                        else if (data.toddlers <= 20) {
                                            return 374.64516;
                                        }
                                    }
                                    else if (data.graduetes <= 33) {
                                        return 630.47083;
                                    }
                                }
                            }
                            else if (data.size <= 0) {
                                if (data.resistance == null) {
                                    return 305.31195;
                                }
                                else if (data.resistance > 18) {
                                    return 1257.15;
                                }
                                else if (data.resistance <= 18) {
                                    return 300.02396;
                                }
                            }
                        }
                        else if (data.graduetes <= 21) {
                            return 1573.2;
                        }
                    }
                    else if (data.toddlers <= 8) {
                        if (data.children == null) {
                            return 269.24488;
                        }
                        else if (data.children > 24) {
                            if (data.resistance == null) {
                                return 376.37188;
                            }
                            else if (data.resistance > 1) {
                                if (data.size > 0) {
                                    return 522.6337;
                                }
                                else if (data.size <= 0) {
                                    return 231.14219;
                                }
                            }
                            else if (data.resistance <= 1) {
                                return 1659.7;
                            }
                        }
                        else if (data.children <= 24) {
                            return 223.79706;
                        }
                    }
                }
            }
        }
        else if (data.weather <= 0) {
            return 19.37169;
        }
    }
    return null;
}