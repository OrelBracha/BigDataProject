
/**
*  Predictor for CHOCOLATE from model/63562ca38be2aa36480022d9
*  Predictive model by BigML - Machine Learning Made Easy
*/
exports.predictChocolate = (data) => {
    if (data.season == null) {
        return 604.93599;
    }
    else if (data.season > 1) {
        if (data.holiday == null) {
            return 1042.33369;
        }
        else if (data.holiday=="0") {
            if (data.size == null) {
                return 784.1666;
            }
            else if (data.size > 3) {
                if (data.toddlers == null) {
                    return 1099.77188;
                }
                else if (data.toddlers > 22) {
                    return 3352.45313;
                }
                else if (data.toddlers <= 22) {
                    if (data.graduetes == null) {
                        return 1085.69262;
                    }
                    else if (data.graduetes > 33) {
                        if (data.resistance == null) {
                            return 986.30069;
                        }
                        else if (data.resistance > 5) {
                            if (data.adults == null) {
                                return 1033.89105;
                            }
                            else if (data.adults > 7) {
                                if (data.toddlers > 14) {
                                    return 1789.92969;
                                }
                                else if (data.toddlers <= 14) {
                                    if (data.month == null) {
                                        return 938.7805;
                                    }
                                    else if (data.month > 5) {
                                        if (data.adults > 14) {
                                            return 387.425;
                                        }
                                        else if (data.adults <= 14) {
                                            if (data.children == null) {
                                                return 1003.80501;
                                            }
                                            else if (data.children > 16) {
                                                return 959.73781;
                                            }
                                            else if (data.children <= 16) {
                                                return 1360.74938;
                                            }
                                        }
                                    }
                                    else if (data.month <= 5) {
                                        return 412.03828;
                                    }
                                }
                            }
                            else if (data.adults <= 7) {
                                return 2520.52313;
                            }
                        }
                        else if (data.resistance <= 5) {
                            if (data.graduetes > 36) {
                                if (data.month == null) {
                                    return 863.23203;
                                }
                                else if (data.month > 8) {
                                    return 299.11667;
                                }
                                else if (data.month <= 8) {
                                    return 1201.70125;
                                }
                            }
                            else if (data.graduetes <= 36) {
                                return 136.2225;
                            }
                        }
                    }
                    else if (data.graduetes <= 33) {
                        return 1416.10363;
                    }
                }
            }
            else if (data.size <= 3) {
                if (data.size > 0) {
                    if (data.type == null) {
                        return 813.31052;
                    }
                    else if (data.type > 0) {
                        if (data.resistance == null) {
                            return 846.76475;
                        }
                        else if (data.resistance > 8) {
                            return 747.66979;
                        }
                        else if (data.resistance <= 8) {
                            if (data.gold == null) {
                                return 908.07253;
                            }
                            else if (data.gold > 21) {
                                if (data.graduetes == null) {
                                    return 459.20893;
                                }
                                else if (data.graduetes > 31) {
                                    return 1561.0625;
                                }
                                else if (data.graduetes <= 31) {
                                    return 275.56667;
                                }
                            }
                            else if (data.gold <= 21) {
                                if (data.toddlers == null) {
                                    return 933.93298;
                                }
                                else if (data.toddlers > 19) {
                                    return 516.18958;
                                }
                                else if (data.toddlers <= 19) {
                                    if (data.adults == null) {
                                        return 961.4161;
                                    }
                                    else if (data.adults > 17) {
                                        return 639.94438;
                                    }
                                    else if (data.adults <= 17) {
                                        return 992.32684;
                                    }
                                }
                            }
                        }
                    }
                    else if (data.type <= 0) {
                        return 573.36296;
                    }
                }
                else if (data.size <= 0) {
                    if (data.month == null) {
                        return 706.95432;
                    }
                    else if (data.month > 7) {
                        if (data.gold == null) {
                            return 658.16401;
                        }
                        else if (data.gold > 19) {
                            return 532.18685;
                        }
                        else if (data.gold <= 19) {
                            return 684.96026;
                        }
                    }
                    else if (data.month <= 7) {
                        if (data.children == null) {
                            return 760.77078;
                        }
                        else if (data.children > 41) {
                            if (data.graduetes == null) {
                                return 1256.23688;
                            }
                            else if (data.graduetes > 29) {
                                return 1570.29609;
                            }
                            else if (data.graduetes <= 29) {
                                return 0;
                            }
                        }
                        else if (data.children <= 41) {
                            if (data.graduetes == null) {
                                return 748.00104;
                            }
                            else if (data.graduetes > 61) {
                                return 1978.6875;
                            }
                            else if (data.graduetes <= 61) {
                                return 744.82097;
                            }
                        }
                    }
                }
            }
        }
        else if (data.holiday=="1") {
            if (data.size == null) {
                return 1614.65593;
            }
            else if (data.size > 3) {
                if (data.graduetes == null) {
                    return 2209.48934;
                }
                else if (data.graduetes > 31) {
                    if (data.graduetes > 32) {
                        if (data.graduetes > 36) {
                            return 1916.7103;
                        }
                        else if (data.graduetes <= 36) {
                            return 2695.78357;
                        }
                    }
                    else if (data.graduetes <= 32) {
                        return 5881.8375;
                    }
                }
                else if (data.graduetes <= 31) {
                    return 979.29205;
                }
            }
            else if (data.size <= 3) {
                if (data.adults == null) {
                    return 1527.33151;
                }
                else if (data.adults > 17) {
                    return 2250.90862;
                }
                else if (data.adults <= 17) {
                    if (data.adults > 2) {
                        if (data.toddlers == null) {
                            return 1473.10117;
                        }
                        else if (data.toddlers > 29) {
                            return 4732.575;
                        }
                        else if (data.toddlers <= 29) {
                            if (data.size > 0) {
                                if (data.graduetes == null) {
                                    return 1632.13649;
                                }
                                else if (data.graduetes > 36) {
                                    if (data.resistance == null) {
                                        return 1210.8118;
                                    }
                                    else if (data.resistance > 6) {
                                        return 1356.24137;
                                    }
                                    else if (data.resistance <= 6) {
                                        return 708.41875;
                                    }
                                }
                                else if (data.graduetes <= 36) {
                                    if (data.weather == null) {
                                        return 1786.20299;
                                    }
                                    else if (data.weather > 1) {
                                        if (data.children == null) {
                                            return 1969.23371;
                                        }
                                        else if (data.children > 18) {
                                            if (data.children > 26) {
                                                return 2252.62996;
                                            }
                                            else if (data.children <= 26) {
                                                if (data.adults > 11) {
                                                    return 1769.27692;
                                                }
                                                else if (data.adults <= 11) {
                                                    if (data.children > 22) {
                                                        return 1520.79688;
                                                    }
                                                    else if (data.children <= 22) {
                                                        return 359.64375;
                                                    }
                                                }
                                            }
                                        }
                                        else if (data.children <= 18) {
                                            if (data.toddlers > 7) {
                                                return 4403.425;
                                            }
                                            else if (data.toddlers <= 7) {
                                                return 1965.65;
                                            }
                                        }
                                    }
                                    else if (data.weather <= 1) {
                                        return 1424.20889;
                                    }
                                }
                            }
                            else if (data.size <= 0) {
                                if (data.children == null) {
                                    return 1383.45315;
                                }
                                else if (data.children > 38) {
                                    if (data.adults > 7) {
                                        return 0;
                                    }
                                    else if (data.adults <= 7) {
                                        return 2616.46445;
                                    }
                                }
                                else if (data.children <= 38) {
                                    if (data.toddlers > 12) {
                                        if (data.children > 14) {
                                            if (data.adults > 9) {
                                                if (data.month == null) {
                                                    return 1425.35625;
                                                }
                                                else if (data.month > 8) {
                                                    return 2510.97;
                                                }
                                                else if (data.month <= 8) {
                                                    if (data.children > 20) {
                                                        return 231.77277;
                                                    }
                                                    else if (data.children <= 20) {
                                                        return 2888.86407;
                                                    }
                                                }
                                            }
                                            else if (data.adults <= 9) {
                                                return 746.95457;
                                            }
                                        }
                                        else if (data.children <= 14) {
                                            return 3251.68125;
                                        }
                                    }
                                    else if (data.toddlers <= 12) {
                                        if (data.graduetes == null) {
                                            return 1434.87197;
                                        }
                                        else if (data.graduetes > 35) {
                                            if (data.children > 17) {
                                                if (data.gold == null) {
                                                    return 1839.84396;
                                                }
                                                else if (data.gold > 11) {
                                                    return 2254.18103;
                                                }
                                                else if (data.gold <= 11) {
                                                    if (data.resistance == null) {
                                                        return 1465.60403;
                                                    }
                                                    else if (data.resistance > 4) {
                                                        return 1298.96748;
                                                    }
                                                    else if (data.resistance <= 4) {
                                                        if (data.gold > 4) {
                                                            return 3417.125;
                                                        }
                                                        else if (data.gold <= 4) {
                                                            return 1763.67657;
                                                        }
                                                    }
                                                }
                                            }
                                            else if (data.children <= 17) {
                                                return 1175.1518;
                                            }
                                        }
                                        else if (data.graduetes <= 35) {
                                            if (data.gold == null) {
                                                return 1354.01997;
                                            }
                                            else if (data.gold > 12) {
                                                if (data.adults > 7) {
                                                    if (data.gold > 21) {
                                                        return 1948.05486;
                                                    }
                                                    else if (data.gold <= 21) {
                                                        if (data.gold > 20) {
                                                            return 617.76094;
                                                        }
                                                        else if (data.gold <= 20) {
                                                            if (data.graduetes > 30) {
                                                                if (data.toddlers > 6) {
                                                                    if (data.adults > 8) {
                                                                        if (data.toddlers > 7) {
                                                                            if (data.resistance == null) {
                                                                                return 1243.3569;
                                                                            }
                                                                            else if (data.resistance > 13) {
                                                                                return 379.99063;
                                                                            }
                                                                            else if (data.resistance <= 13) {
                                                                                if (data.resistance > 9) {
                                                                                    return 1652.61853;
                                                                                }
                                                                                else if (data.resistance <= 9) {
                                                                                    return 1164.86808;
                                                                                }
                                                                            }
                                                                        }
                                                                        else if (data.toddlers <= 7) {
                                                                            return 789.69271;
                                                                        }
                                                                    }
                                                                    else if (data.adults <= 8) {
                                                                        if (data.weather == null) {
                                                                            return 2409.86875;
                                                                        }
                                                                        else if (data.weather > 1) {
                                                                            return 3882.9;
                                                                        }
                                                                        else if (data.weather <= 1) {
                                                                            return 936.8375;
                                                                        }
                                                                    }
                                                                }
                                                                else if (data.toddlers <= 6) {
                                                                    return 2029.84201;
                                                                }
                                                            }
                                                            else if (data.graduetes <= 30) {
                                                                return 1738.29309;
                                                            }
                                                        }
                                                    }
                                                }
                                                else if (data.adults <= 7) {
                                                    return 591.14766;
                                                }
                                            }
                                            else if (data.gold <= 12) {
                                                if (data.toddlers > 11) {
                                                    return 2050.13646;
                                                }
                                                else if (data.toddlers <= 11) {
                                                    if (data.graduetes > 32) {
                                                        return 891.375;
                                                    }
                                                    else if (data.graduetes <= 32) {
                                                        return 1280.53992;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else if (data.adults <= 2) {
                        if (data.toddlers == null) {
                            return 3241.69063;
                        }
                        else if (data.toddlers > 28) {
                            return 1006.04532;
                        }
                        else if (data.toddlers <= 28) {
                            return 4732.12083;
                        }
                    }
                }
            }
        }
    }
    else if (data.season <= 1) {
        if (data.weather == null) {
            return 233.00864;
        }
        else if (data.weather > 0) {
            if (data.holiday == null) {
                return 495.77739;
            }
            else if (data.holiday=="1") {
                if (data.size == null) {
                    return 681.81614;
                }
                else if (data.size > 5) {
                    if (data.month == null) {
                        return 1097.48382;
                    }
                    else if (data.month > 2) {
                        return 1422.37292;
                    }
                    else if (data.month <= 2) {
                        return 317.75;
                    }
                }
                else if (data.size <= 5) {
                    if (data.resistance == null) {
                        return 654.05052;
                    }
                    else if (data.resistance > 7) {
                        if (data.size > 0) {
                            if (data.children == null) {
                                return 802.25614;
                            }
                            else if (data.children > 27) {
                                return 1656.6;
                            }
                            else if (data.children <= 27) {
                                if (data.graduetes == null) {
                                    return 778.30257;
                                }
                                else if (data.graduetes > 40) {
                                    return 408.81591;
                                }
                                else if (data.graduetes <= 40) {
                                    if (data.toddlers == null) {
                                        return 820.63958;
                                    }
                                    else if (data.toddlers > 7) {
                                        if (data.children > 20) {
                                            return 815.0447;
                                        }
                                        else if (data.children <= 20) {
                                            return 1202.20313;
                                        }
                                    }
                                    else if (data.toddlers <= 7) {
                                        return 647.46192;
                                    }
                                }
                            }
                        }
                        else if (data.size <= 0) {
                            return 646.27367;
                        }
                    }
                    else if (data.resistance <= 7) {
                        if (data.adults == null) {
                            return 591.04498;
                        }
                        else if (data.adults > 18) {
                            if (data.toddlers == null) {
                                return 1136.13214;
                            }
                            else if (data.toddlers > 6) {
                                return 273.40625;
                            }
                            else if (data.toddlers <= 6) {
                                return 1481.2225;
                            }
                        }
                        else if (data.adults <= 18) {
                            if (data.children == null) {
                                return 574.59838;
                            }
                            else if (data.children > 38) {
                                return 920.435;
                            }
                            else if (data.children <= 38) {
                                return 550.69263;
                            }
                        }
                    }
                }
            }
            else if (data.holiday=="0") {
                if (data.size == null) {
                    return 304.81512;
                }
                else if (data.size > 4) {
                    return 465.30357;
                }
                else if (data.size <= 4) {
                    return 285.81438;
                }
            }
        }
        else if (data.weather <= 0) {
            if (data.holiday == null) {
                return 37.3919;
            }
            else if (data.holiday=="1") {
                return 103.64722;
            }
            else if (data.holiday=="0") {
                return 21.18598;
            }
        }
    }
    return null;
}