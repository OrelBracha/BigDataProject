
/**
*  Predictor for HALVA from model/63562d6a8be2aa364300235b
*  Predictive model by BigML - Machine Learning Made Easy
*/
exports.predictHalva = (data) => {
    if (data.season == null) {
        return 148.96079;
    }
    else if (data.season > 1) {
        if (data.holyday == null) {
            return 253.498;
        }
        else if (data.holyday=="0") {
            if (data.size == null) {
                return 179.26564;
            }
            else if (data.size > 3) {
                if (data.adults == null) {
                    return 262.16796;
                }
                else if (data.adults > 5) {
                    if (data.gold == null) {
                        return 256.04963;
                    }
                    else if (data.gold > 25) {
                        return 581.49375;
                    }
                    else if (data.gold <= 25) {
                        if (data.toddlers == null) {
                            return 249.83095;
                        }
                        else if (data.toddlers > 7) {
                            if (data.month == null) {
                                return 271.14108;
                            }
                            else if (data.month > 6) {
                                if (data.resistance == null) {
                                    return 235.29253;
                                }
                                else if (data.resistance > 7) {
                                    return 159.81199;
                                }
                                else if (data.resistance <= 7) {
                                    if (data.children == null) {
                                        return 304.73463;
                                    }
                                    else if (data.children > 22) {
                                        if (data.month > 8) {
                                            return 158.44732;
                                        }
                                        else if (data.month <= 8) {
                                            return 336.6536;
                                        }
                                    }
                                    else if (data.children <= 22) {
                                        return 636.3;
                                    }
                                }
                            }
                            else if (data.month <= 6) {
                                return 355.07915;
                            }
                        }
                        else if (data.toddlers <= 7) {
                            return 103.85656;
                        }
                    }
                }
                else if (data.adults <= 5) {
                    return 1241.1;
                }
            }
            else if (data.size <= 3) {
                if (data.children == null) {
                    return 169.08465;
                }
                else if (data.children > 28) {
                    if (data.graduetes == null) {
                        return 212.28065;
                    }
                    else if (data.graduetes > 31) {
                        if (data.adults == null) {
                            return 238.48456;
                        }
                        else if (data.adults > 18) {
                            return 764.6875;
                        }
                        else if (data.adults <= 18) {
                            if (data.children > 33) {
                                if (data.graduetes > 33) {
                                    return 224.57511;
                                }
                                else if (data.graduetes <= 33) {
                                    return 483.26379;
                                }
                            }
                            else if (data.children <= 33) {
                                return 197.8753;
                            }
                        }
                    }
                    else if (data.graduetes <= 31) {
                        if (data.children > 29) {
                            return 152.66133;
                        }
                        else if (data.children <= 29) {
                            return 492.17187;
                        }
                    }
                }
                else if (data.children <= 28) {
                    if (data.gold == null) {
                        return 157.93329;
                    }
                    else if (data.gold > 9) {
                        if (data.resistance == null) {
                            return 168.10321;
                        }
                        else if (data.resistance > 5) {
                            if (data.gold > 13) {
                                if (data.gold > 15) {
                                    if (data.resistance > 9) {
                                        if (data.children > 19) {
                                            return 214.41067;
                                        }
                                        else if (data.children <= 19) {
                                            return 92.10962;
                                        }
                                    }
                                    else if (data.resistance <= 9) {
                                        if (data.adults == null) {
                                            return 190.25061;
                                        }
                                        else if (data.adults > 10) {
                                            if (data.resistance > 7) {
                                                if (data.children > 23) {
                                                    return 662.17188;
                                                }
                                                else if (data.children <= 23) {
                                                    return 163.5372;
                                                }
                                            }
                                            else if (data.resistance <= 7) {
                                                return 112.75419;
                                            }
                                        }
                                        else if (data.adults <= 10) {
                                            return 294.17468;
                                        }
                                    }
                                }
                                else if (data.gold <= 15) {
                                    return 97.13285;
                                }
                            }
                            else if (data.gold <= 13) {
                                if (data.toddlers == null) {
                                    return 190.52284;
                                }
                                else if (data.toddlers > 4) {
                                    return 185.29953;
                                }
                                else if (data.toddlers <= 4) {
                                    return 553.54297;
                                }
                            }
                        }
                        else if (data.resistance <= 5) {
                            if (data.graduetes == null) {
                                return 234.99929;
                            }
                            else if (data.graduetes > 32) {
                                return 149.05668;
                            }
                            else if (data.graduetes <= 32) {
                                return 314.33093;
                            }
                        }
                    }
                    else if (data.gold <= 9) {
                        return 121.42013;
                    }
                }
            }
        }
        else if (data.holyday=="1") {
            if (data.size == null) {
                return 418.0613;
            }
            else if (data.size > 4) {
                if (data.children == null) {
                    return 674.10993;
                }
                else if (data.children > 40) {
                    return 2302.8;
                }
                else if (data.children <= 40) {
                    if (data.resistance == null) {
                        return 649.43281;
                    }
                    else if (data.resistance > 7) {
                        return 796.41984;
                    }
                    else if (data.resistance <= 7) {
                        return 374.63098;
                    }
                }
            }
            else if (data.size <= 4) {
                if (data.toddlers == null) {
                    return 389.32552;
                }
                else if (data.toddlers > 4) {
                    if (data.adults == null) {
                        return 380.64172;
                    }
                    else if (data.adults > 10) {
                        if (data.toddlers > 16) {
                            return 2453.01563;
                        }
                        else if (data.toddlers <= 16) {
                            if (data.children == null) {
                                return 411.02328;
                            }
                            else if (data.children > 21) {
                                if (data.weather == null) {
                                    return 456.58309;
                                }
                                else if (data.weather > 1) {
                                    if (data.toddlers > 6) {
                                        if (data.graduetes == null) {
                                            return 479.34988;
                                        }
                                        else if (data.graduetes > 31) {
                                            if (data.resistance == null) {
                                                return 558.79834;
                                            }
                                            else if (data.resistance > 7) {
                                                if (data.children > 29) {
                                                    return 1560;
                                                }
                                                else if (data.children <= 29) {
                                                    if (data.toddlers > 11) {
                                                        return 1470;
                                                    }
                                                    else if (data.toddlers <= 11) {
                                                        if (data.resistance > 10) {
                                                            return 723.22098;
                                                        }
                                                        else if (data.resistance <= 10) {
                                                            return 291.53786;
                                                        }
                                                    }
                                                }
                                            }
                                            else if (data.resistance <= 7) {
                                                if (data.type == null) {
                                                    return 750.36286;
                                                }
                                                else if (data.type > 1) {
                                                    if (data.resistance > 4) {
                                                        if (data.toddlers > 9) {
                                                            if (data.gold == null) {
                                                                return 833.91809;
                                                            }
                                                            else if (data.gold > 11) {
                                                                return 1927.5;
                                                            }
                                                            else if (data.gold <= 11) {
                                                                return 705.2614;
                                                            }
                                                        }
                                                        else if (data.toddlers <= 9) {
                                                            if (data.month == null) {
                                                                return 1977.67344;
                                                            }
                                                            else if (data.month > 5) {
                                                                return 63.34688;
                                                            }
                                                            else if (data.month <= 5) {
                                                                if (data.children > 26) {
                                                                    return 3372.96094;
                                                                }
                                                                else if (data.children <= 26) {
                                                                    return 2496.7125;
                                                                }
                                                            }
                                                        }
                                                    }
                                                    else if (data.resistance <= 4) {
                                                        return 328;
                                                    }
                                                }
                                                else if (data.type <= 1) {
                                                    return 235.34813;
                                                }
                                            }
                                        }
                                        else if (data.graduetes <= 31) {
                                            return 273.21335;
                                        }
                                    }
                                    else if (data.toddlers <= 6) {
                                        return 776.53073;
                                    }
                                }
                                else if (data.weather <= 1) {
                                    if (data.resistance == null) {
                                        return 372.09231;
                                    }
                                    else if (data.resistance > 7) {
                                        return 470.55056;
                                    }
                                    else if (data.resistance <= 7) {
                                        if (data.size > 2) {
                                            return 1737.75;
                                        }
                                        else if (data.size <= 2) {
                                            if (data.children > 22) {
                                                if (data.resistance > 1) {
                                                    if (data.graduetes == null) {
                                                        return 237.28682;
                                                    }
                                                    else if (data.graduetes > 29) {
                                                        return 282.18274;
                                                    }
                                                    else if (data.graduetes <= 29) {
                                                        return 92.23846;
                                                    }
                                                }
                                                else if (data.resistance <= 1) {
                                                    return 996.4;
                                                }
                                            }
                                            else if (data.children <= 22) {
                                                return 868.95;
                                            }
                                        }
                                    }
                                }
                            }
                            else if (data.children <= 21) {
                                if (data.children > 12) {
                                    if (data.graduetes == null) {
                                        return 312.89695;
                                    }
                                    else if (data.graduetes > 40) {
                                        return 515.29594;
                                    }
                                    else if (data.graduetes <= 40) {
                                        if (data.gold == null) {
                                            return 295.59789;
                                        }
                                        else if (data.gold > 14) {
                                            if (data.gold > 18) {
                                                return 232.55839;
                                            }
                                            else if (data.gold <= 18) {
                                                return 492.16985;
                                            }
                                        }
                                        else if (data.gold <= 14) {
                                            return 200.31021;
                                        }
                                    }
                                }
                                else if (data.children <= 12) {
                                    return 833.17032;
                                }
                            }
                        }
                    }
                    else if (data.adults <= 10) {
                        if (data.graduetes == null) {
                            return 312.28901;
                        }
                        else if (data.graduetes > 46) {
                            return 1253.27344;
                        }
                        else if (data.graduetes <= 46) {
                            if (data.resistance == null) {
                                return 302.83188;
                            }
                            else if (data.resistance > 2) {
                                if (data.children == null) {
                                    return 324.38079;
                                }
                                else if (data.children > 36) {
                                    return 722.76528;
                                }
                                else if (data.children <= 36) {
                                    if (data.resistance > 11) {
                                        return 523.49714;
                                    }
                                    else if (data.resistance <= 11) {
                                        if (data.toddlers > 12) {
                                            if (data.children > 30) {
                                                return 222.50569;
                                            }
                                            else if (data.children <= 30) {
                                                return 480.14672;
                                            }
                                        }
                                        else if (data.toddlers <= 12) {
                                            return 215.62507;
                                        }
                                    }
                                }
                            }
                            else if (data.resistance <= 2) {
                                return 145.70443;
                            }
                        }
                    }
                }
                else if (data.toddlers <= 4) {
                    if (data.adults == null) {
                        return 851.93523;
                    }
                    else if (data.adults > 13) {
                        return 286.17563;
                    }
                    else if (data.adults <= 13) {
                        if (data.children == null) {
                            return 1323.40156;
                        }
                        else if (data.children > 10) {
                            return 2197.6;
                        }
                        else if (data.children <= 10) {
                            return 449.20313;
                        }
                    }
                }
            }
        }
    }
    else if (data.season <= 1) {
        if (data.weather == null) {
            return 60.07087;
        }
        else if (data.weather > 0) {
            if (data.holyday == null) {
                return 128.86068;
            }
            else if (data.holyday=="0") {
                return 84.9921;
            }
            else if (data.holyday=="1") {
                if (data.size == null) {
                    return 171.59823;
                }
                else if (data.size > 6) {
                    return 404.30714;
                }
                else if (data.size <= 6) {
                    if (data.children == null) {
                        return 162.23638;
                    }
                    else if (data.children > 26) {
                        if (data.gold == null) {
                            return 210.91335;
                        }
                        else if (data.gold > 4) {
                            if (data.size > 2) {
                                return 650.485;
                            }
                            else if (data.size <= 2) {
                                if (data.toddlers == null) {
                                    return 244.26536;
                                }
                                else if (data.toddlers > 14) {
                                    return 54.08333;
                                }
                                else if (data.toddlers <= 14) {
                                    if (data.resistance == null) {
                                        return 272.325;
                                    }
                                    else if (data.resistance > 4) {
                                        return 228.14464;
                                    }
                                    else if (data.resistance <= 4) {
                                        if (data.gold > 5) {
                                            return 363.9525;
                                        }
                                        else if (data.gold <= 5) {
                                            return 896.60625;
                                        }
                                    }
                                }
                            }
                        }
                        else if (data.gold <= 4) {
                            return 132.76681;
                        }
                    }
                    else if (data.children <= 26) {
                        if (data.size > 0) {
                            if (data.resistance == null) {
                                return 185.03711;
                            }
                            else if (data.resistance > 9) {
                                if (data.size > 4) {
                                    return 559.25;
                                }
                                else if (data.size <= 4) {
                                    return 210.49622;
                                }
                            }
                            else if (data.resistance <= 9) {
                                return 155.21551;
                            }
                        }
                        else if (data.size <= 0) {
                            return 117.74095;
                        }
                    }
                }
            }
        }
        else if (data.weather <= 0) {
            return 8.86067;
        }
    }
    return null;
}