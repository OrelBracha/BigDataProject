
exports.predictVanila = (data) => {
    console.log(data);
    if (data.season == null) {
        return 1160.9319;
    }
    else if (data.season > 1) {
        if (data.holiday == null) {
            return 1958.27584;
        }
        else if (data.holiday=="0") {
            if (data.size == null) {
                return 1439.32861;
            }
            else if (data.size > 4) {
                if (data.graduetes == null) {
                    return 2192.0911;
                }
                else if (data.graduetes > 34) {
                    if (data.weather == null) {
                        return 2018.30999;
                    }
                    else if (data.weather > 1) {
                        return 2483.10579;
                    }
                    else if (data.weather <= 1) {
                        return 1642.04673;
                    }
                }
                else if (data.graduetes <= 34) {
                    if (data.resistance == null) {
                        return 2473.09884;
                    }
                    else if (data.resistance > 1) {
                        return 2524.29229;
                    }
                    else if (data.resistance <= 1) {
                        return 118.2;
                    }
                }
            }
            else if (data.size <= 4) {
                if (data.season > 2) {
                    if (data.children == null) {
                        return 1277.17345;
                    }
                    else if (data.children > 41) {
                        return 2055.435;
                    }
                    else if (data.children <= 41) {
                        if (data.children > 17) {
                            return 1292.03252;
                        }
                        else if (data.children <= 17) {
                            if (data.graduetes == null) {
                                return 1043.34418;
                            }
                            else if (data.graduetes > 66) {
                                return 2821.5;
                            }
                            else if (data.graduetes <= 66) {
                                if (data.gold == null) {
                                    return 1018.64757;
                                }
                                else if (data.gold > 30) {
                                    return 409.61607;
                                }
                                else if (data.gold <= 30) {
                                    return 1084.23558;
                                }
                            }
                        }
                    }
                }
                else if (data.season <= 2) {
                    if (data.type == null) {
                        return 1473.98706;
                    }
                    else if (data.type > 0) {
                        if (data.gold == null) {
                            return 1503.10232;
                        }
                        else if (data.gold > 18) {
                            if (data.children == null) {
                                return 1261.84675;
                            }
                            else if (data.children > 23) {
                                return 408.57813;
                            }
                            else if (data.children <= 23) {
                                return 1311.07378;
                            }
                        }
                        else if (data.gold <= 18) {
                            if (data.resistance == null) {
                                return 1556.71467;
                            }
                            else if (data.resistance > 13) {
                                return 1137.19933;
                            }
                            else if (data.resistance <= 13) {
                                return 1575.30079;
                            }
                        }
                    }
                    else if (data.type <= 0) {
                        return 984.68893;
                    }
                }
            }
        }
        else if (data.holiday=="1") {
            if (data.size == null) {
                return 3108.71306;
            }
            else if (data.size > 5) {
                return 4830.64931;
            }
            else if (data.size <= 5) {
                if (data.children == null) {
                    return 2995.39142;
                }
                else if (data.children > 28) {
                    if (data.children > 49) {
                        return 6754.23281;
                    }
                    else if (data.children <= 49) {
                        if (data.size > 2) {
                            return 4542.20573;
                        }
                        else if (data.size <= 2) {
                            if (data.type == null) {
                                return 3397.25383;
                            }
                            else if (data.type > 1) {
                                if (data.month == null) {
                                    return 3639.08469;
                                }
                                else if (data.month > 8) {
                                    if (data.resistance == null) {
                                        return 3092.58125;
                                    }
                                    else if (data.resistance > 6) {
                                        return 5257.67917;
                                    }
                                    else if (data.resistance <= 6) {
                                        return 2592.94327;
                                    }
                                }
                                else if (data.month <= 8) {
                                    if (data.graduetes == null) {
                                        return 3896.26278;
                                    }
                                    else if (data.graduetes > 29) {
                                        if (data.children > 32) {
                                            return 4754.73786;
                                        }
                                        else if (data.children <= 32) {
                                            return 3525.9176;
                                        }
                                    }
                                    else if (data.graduetes <= 29) {
                                        return 2962.09635;
                                    }
                                }
                            }
                            else if (data.type <= 1) {
                                return 2188.09953;
                            }
                        }
                    }
                }
                else if (data.children <= 28) {
                    if (data.graduetes == null) {
                        return 2843.44266;
                    }
                    else if (data.graduetes > 30) {
                        if (data.children > 21) {
                            if (data.toddlers == null) {
                                return 3200.99794;
                            }
                            else if (data.toddlers > 11) {
                                if (data.size > 2) {
                                    return 4203.435;
                                }
                                else if (data.size <= 2) {
                                    return 2414.7202;
                                }
                            }
                            else if (data.toddlers <= 11) {
                                if (data.month == null) {
                                    return 3365.55655;
                                }
                                else if (data.month > 8) {
                                    if (data.graduetes > 43) {
                                        return 568.3375;
                                    }
                                    else if (data.graduetes <= 43) {
                                        if (data.adults == null) {
                                            return 3015.71471;
                                        }
                                        else if (data.adults > 11) {
                                            return 2661.79531;
                                        }
                                        else if (data.adults <= 11) {
                                            return 3611.78947;
                                        }
                                    }
                                }
                                else if (data.month <= 8) {
                                    if (data.children > 24) {
                                        if (data.adults == null) {
                                            return 3114.29677;
                                        }
                                        else if (data.adults > 14) {
                                            return 3867.10067;
                                        }
                                        else if (data.adults <= 14) {
                                            return 2874.76825;
                                        }
                                    }
                                    else if (data.children <= 24) {
                                        if (data.adults == null) {
                                            return 3959.45405;
                                        }
                                        else if (data.adults > 15) {
                                            return 2199.00375;
                                        }
                                        else if (data.adults <= 15) {
                                            if (data.toddlers > 6) {
                                                if (data.gold == null) {
                                                    return 4211.0426;
                                                }
                                                else if (data.gold > 18) {
                                                    return 355.275;
                                                }
                                                else if (data.gold <= 18) {
                                                    if (data.type == null) {
                                                        return 4279.89559;
                                                    }
                                                    else if (data.type > 0) {
                                                        if (data.gold > 8) {
                                                            return 4304.96964;
                                                        }
                                                        else if (data.gold <= 8) {
                                                            return 5852.60938;
                                                        }
                                                    }
                                                    else if (data.type <= 0) {
                                                        if (data.gold > 6) {
                                                            if (data.month > 5) {
                                                                return 3716.23594;
                                                            }
                                                            else if (data.month <= 5) {
                                                                return 973.025;
                                                            }
                                                        }
                                                        else if (data.gold <= 6) {
                                                            return 4466.075;
                                                        }
                                                    }
                                                }
                                            }
                                            else if (data.toddlers <= 6) {
                                                return 1190.30625;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else if (data.children <= 21) {
                            if (data.children > 11) {
                                if (data.resistance == null) {
                                    return 2742.07795;
                                }
                                else if (data.resistance > 13) {
                                    if (data.graduetes > 40) {
                                        return 5481.38906;
                                    }
                                    else if (data.graduetes <= 40) {
                                        if (data.graduetes > 37) {
                                            return 912.94688;
                                        }
                                        else if (data.graduetes <= 37) {
                                            return 4059.74792;
                                        }
                                    }
                                }
                                else if (data.resistance <= 13) {
                                    if (data.toddlers == null) {
                                        return 2659.67199;
                                    }
                                    else if (data.toddlers > 18) {
                                        return 821.76979;
                                    }
                                    else if (data.toddlers <= 18) {
                                        if (data.month == null) {
                                            return 2693.49841;
                                        }
                                        else if (data.month > 9) {
                                            return 1970.06833;
                                        }
                                        else if (data.month <= 9) {
                                            if (data.toddlers > 5) {
                                                if (data.gold == null) {
                                                    return 2718.13346;
                                                }
                                                else if (data.gold > 7) {
                                                    if (data.graduetes > 43) {
                                                        return 4633.30313;
                                                    }
                                                    else if (data.graduetes <= 43) {
                                                        if (data.type == null) {
                                                            return 2704.69185;
                                                        }
                                                        else if (data.type > 0) {
                                                            if (data.size > 0) {
                                                                return 3175.43643;
                                                            }
                                                            else if (data.size <= 0) {
                                                                if (data.gold > 27) {
                                                                    return 4431.75;
                                                                }
                                                                else if (data.gold <= 27) {
                                                                    if (data.children > 14) {
                                                                        if (data.children > 15) {
                                                                            if (data.weather == null) {
                                                                                return 2584.6223;
                                                                            }
                                                                            else if (data.weather > 1) {
                                                                                if (data.resistance > 9) {
                                                                                    if (data.adults == null) {
                                                                                        return 2408.78632;
                                                                                    }
                                                                                    else if (data.adults > 14) {
                                                                                        return 3595.99375;
                                                                                    }
                                                                                    else if (data.adults <= 14) {
                                                                                        return 2271.80084;
                                                                                    }
                                                                                }
                                                                                else if (data.resistance <= 9) {
                                                                                    return 3067.04305;
                                                                                }
                                                                            }
                                                                            else if (data.weather <= 1) {
                                                                                if (data.gold > 14) {
                                                                                    if (data.adults == null) {
                                                                                        return 1898.68375;
                                                                                    }
                                                                                    else if (data.adults > 8) {
                                                                                        if (data.children > 16) {
                                                                                            return 2303.60667;
                                                                                        }
                                                                                        else if (data.children <= 16) {
                                                                                            return 572.4;
                                                                                        }
                                                                                    }
                                                                                    else if (data.adults <= 8) {
                                                                                        return 758.25833;
                                                                                    }
                                                                                }
                                                                                else if (data.gold <= 14) {
                                                                                    if (data.resistance > 11) {
                                                                                        return 702.3;
                                                                                    }
                                                                                    else if (data.resistance <= 11) {
                                                                                        if (data.resistance > 10) {
                                                                                            return 5017.58333;
                                                                                        }
                                                                                        else if (data.resistance <= 10) {
                                                                                            return 2694.2;
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                        else if (data.children <= 15) {
                                                                            return 3724.71406;
                                                                        }
                                                                    }
                                                                    else if (data.children <= 14) {
                                                                        return 1216.9375;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        else if (data.type <= 0) {
                                                            return 1207.87813;
                                                        }
                                                    }
                                                }
                                                else if (data.gold <= 7) {
                                                    return 772.85;
                                                }
                                            }
                                            else if (data.toddlers <= 5) {
                                                if (data.graduetes > 37) {
                                                    return 2766.37032;
                                                }
                                                else if (data.graduetes <= 37) {
                                                    return 5087.79688;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            else if (data.children <= 11) {
                                return 969.17396;
                            }
                        }
                    }
                    else if (data.graduetes <= 30) {
                        if (data.children > 17) {
                            if (data.adults == null) {
                                return 2337.46883;
                            }
                            else if (data.adults > 18) {
                                return 1078.91027;
                            }
                            else if (data.adults <= 18) {
                                if (data.graduetes > 26) {
                                    if (data.children > 18) {
                                        if (data.gold == null) {
                                            return 2324.48906;
                                        }
                                        else if (data.gold > 12) {
                                            if (data.adults > 14) {
                                                return 2668.69163;
                                            }
                                            else if (data.adults <= 14) {
                                                return 2146.45469;
                                            }
                                        }
                                        else if (data.gold <= 12) {
                                            return 128.6625;
                                        }
                                    }
                                    else if (data.children <= 18) {
                                        return 3892.38333;
                                    }
                                }
                                else if (data.graduetes <= 26) {
                                    return 4812.425;
                                }
                            }
                        }
                        else if (data.children <= 17) {
                            return 1000.17545;
                        }
                    }
                }
            }
        }
    }
    else if (data.season <= 1) {
        if (data.weather == null) {
            return 482.93562;
        }
        else if (data.weather > 0) {
            if (data.holiday == null) {
                return 1019.98968;
            }
            else if (data.holiday=="0") {
                if (data.size == null) {
                    return 621.30671;
                }
                else if (data.size > 5) {
                    return 990.80701;
                }
                else if (data.size <= 5) {
                    return 596.72302;
                }
            }
            else if (data.holiday=="1") {
                if (data.size == null) {
                    return 1408.39353;
                }
                else if (data.size > 4) {
                    if (data.month == null) {
                        return 1881.73616;
                    }
                    else if (data.month > 3) {
                        return 1372.39286;
                    }
                    else if (data.month <= 3) {
                        return 2391.07946;
                    }
                }
                else if (data.size <= 4) {
                    if (data.children == null) {
                        return 1353.96399;
                    }
                    else if (data.children > 20) {
                        if (data.type == null) {
                            return 1432.16451;
                        }
                        else if (data.type > 0) {
                            if (data.gold == null) {
                                return 1468.60214;
                            }
                            else if (data.gold > 4) {
                                if (data.graduetes == null) {
                                    return 1395.93493;
                                }
                                else if (data.graduetes > 26) {
                                    if (data.adults == null) {
                                        return 1415.10521;
                                    }
                                    else if (data.adults > 16) {
                                        return 1723.28042;
                                    }
                                    else if (data.adults <= 16) {
                                        if (data.graduetes > 40) {
                                            return 2133.785;
                                        }
                                        else if (data.graduetes <= 40) {
                                            if (data.month == null) {
                                                return 1354.54552;
                                            }
                                            else if (data.month > 3) {
                                                if (data.toddlers == null) {
                                                    return 1459.76752;
                                                }
                                                else if (data.toddlers > 8) {
                                                    return 1356.39048;
                                                }
                                                else if (data.toddlers <= 8) {
                                                    return 1727.33162;
                                                }
                                            }
                                            else if (data.month <= 3) {
                                                return 1211.91125;
                                            }
                                        }
                                    }
                                }
                                else if (data.graduetes <= 26) {
                                    return 606.75833;
                                }
                            }
                            else if (data.gold <= 4) {
                                if (data.adults == null) {
                                    return 1791.14254;
                                }
                                else if (data.adults > 15) {
                                    return 838.04375;
                                }
                                else if (data.adults <= 15) {
                                    if (data.children > 39) {
                                        if (data.graduetes == null) {
                                            return 1380.85865;
                                        }
                                        else if (data.graduetes > 30) {
                                            return 640.405;
                                        }
                                        else if (data.graduetes <= 30) {
                                            return 1843.64219;
                                        }
                                    }
                                    else if (data.children <= 39) {
                                        return 2019.79469;
                                    }
                                }
                            }
                        }
                        else if (data.type <= 0) {
                            return 997.71587;
                        }
                    }
                    else if (data.children <= 20) {
                        return 1179.95489;
                    }
                }
            }
        }
        else if (data.weather <= 0) {
            if (data.holiday == null) {
                return 83.12871;
            }
            else if (data.holiday=="1") {
                return 257.80952;
            }
            else if (data.holiday=="0") {
                return 40.40212;
            }
        }
    }
    return null;
}