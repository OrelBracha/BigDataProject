
/**
*  Predictor for STRAWBERRY from model/63562d4a8f679a1844001c2e
*  Predictive model by BigML - Machine Learning Made Easy
*/
exports.predictStrawberry = (data) => {
    if (data.season == null) {
        return 149.3624;
    }
    else if (data.season > 1) {
        if (data.holiday == null) {
            return 254.94108;
        }
        else if (data.holiday=="0") {
            if (data.size == null) {
                return 180.33882;
            }
            else if (data.size > 6) {
                if (data.month == null) {
                    return 304.5575;
                }
                else if (data.month > 6) {
                    return 150.33437;
                }
                else if (data.month <= 6) {
                    return 519.1288;
                }
            }
            else if (data.size <= 6) {
                if (data.adults == null) {
                    return 175.51735;
                }
                else if (data.adults > 13) {
                    if (data.resistance == null) {
                        return 213.41141;
                    }
                    else if (data.resistance > 4) {
                        if (data.children == null) {
                            return 199.38358;
                        }
                        else if (data.children > 16) {
                            if (data.gold == null) {
                                return 193.19573;
                            }
                            else if (data.gold > 13) {
                                if (data.resistance > 5) {
                                    return 141.42406;
                                }
                                else if (data.resistance <= 5) {
                                    return 353.60239;
                                }
                            }
                            else if (data.gold <= 13) {
                                if (data.gold > 9) {
                                    if (data.size > 2) {
                                        return 495.47813;
                                    }
                                    else if (data.size <= 2) {
                                        if (data.graduetes == null) {
                                            return 243.74978;
                                        }
                                        else if (data.graduetes > 25) {
                                            if (data.children > 27) {
                                                return 61.02149;
                                            }
                                            else if (data.children <= 27) {
                                                if (data.graduetes > 31) {
                                                    if (data.size > 0) {
                                                        return 128.89387;
                                                    }
                                                    else if (data.size <= 0) {
                                                        return 289.34792;
                                                    }
                                                }
                                                else if (data.graduetes <= 31) {
                                                    return 368.27921;
                                                }
                                            }
                                        }
                                        else if (data.graduetes <= 25) {
                                            return 679.6875;
                                        }
                                    }
                                }
                                else if (data.gold <= 9) {
                                    return 159.02398;
                                }
                            }
                        }
                        else if (data.children <= 16) {
                            return 379.78329;
                        }
                    }
                    else if (data.resistance <= 4) {
                        return 424.90793;
                    }
                }
                else if (data.adults <= 13) {
                    if (data.children == null) {
                        return 159.66178;
                    }
                    else if (data.children > 12) {
                        if (data.graduetes == null) {
                            return 162.99219;
                        }
                        else if (data.graduetes > 41) {
                            if (data.graduetes > 50) {
                                return 379.54219;
                            }
                            else if (data.graduetes <= 50) {
                                return 93.33739;
                            }
                        }
                        else if (data.graduetes <= 41) {
                            if (data.month == null) {
                                return 168.96838;
                            }
                            else if (data.month > 5) {
                                if (data.month > 6) {
                                    if (data.gold == null) {
                                        return 163.0035;
                                    }
                                    else if (data.gold > 5) {
                                        return 151.48013;
                                    }
                                    else if (data.gold <= 5) {
                                        if (data.children > 32) {
                                            if (data.toddlers == null) {
                                                return 266.77656;
                                            }
                                            else if (data.toddlers > 12) {
                                                if (data.toddlers > 22) {
                                                    return 79.85625;
                                                }
                                                else if (data.toddlers <= 22) {
                                                    if (data.toddlers > 21) {
                                                        return 1122.9;
                                                    }
                                                    else if (data.toddlers <= 21) {
                                                        if (data.type == null) {
                                                            return 256.57357;
                                                        }
                                                        else if (data.type > 1) {
                                                            return 208.67209;
                                                        }
                                                        else if (data.type <= 1) {
                                                            return 404.26979;
                                                        }
                                                    }
                                                }
                                            }
                                            else if (data.toddlers <= 12) {
                                                return 598.30313;
                                            }
                                        }
                                        else if (data.children <= 32) {
                                            if (data.toddlers == null) {
                                                return 155.25856;
                                            }
                                            else if (data.toddlers > 15) {
                                                return 94.35308;
                                            }
                                            else if (data.toddlers <= 15) {
                                                return 231.3904;
                                            }
                                        }
                                    }
                                }
                                else if (data.month <= 6) {
                                    if (data.children > 41) {
                                        return 1195.875;
                                    }
                                    else if (data.children <= 41) {
                                        if (data.size > 3) {
                                            return 483.46719;
                                        }
                                        else if (data.size <= 3) {
                                            if (data.toddlers == null) {
                                                return 196.71348;
                                            }
                                            else if (data.toddlers > 5) {
                                                if (data.children > 32) {
                                                    return 68.72237;
                                                }
                                                else if (data.children <= 32) {
                                                    if (data.resistance == null) {
                                                        return 208.78428;
                                                    }
                                                    else if (data.resistance > 1) {
                                                        if (data.children > 27) {
                                                            return 317.95488;
                                                        }
                                                        else if (data.children <= 27) {
                                                            return 186.28819;
                                                        }
                                                    }
                                                    else if (data.resistance <= 1) {
                                                        return 756.65625;
                                                    }
                                                }
                                            }
                                            else if (data.toddlers <= 5) {
                                                return 656.50625;
                                            }
                                        }
                                    }
                                }
                            }
                            else if (data.month <= 5) {
                                return 103.22554;
                            }
                        }
                    }
                    else if (data.children <= 12) {
                        return 48.26546;
                    }
                }
            }
        }
        else if (data.holiday=="1") {
            if (data.children == null) {
                return 420.32439;
            }
            else if (data.children > 35) {
                return 835.68024;
            }
            else if (data.children <= 35) {
                if (data.month == null) {
                    return 395.81376;
                }
                else if (data.month > 6) {
                    if (data.children > 26) {
                        if (data.resistance == null) {
                            return 183.89716;
                        }
                        else if (data.resistance > 11) {
                            return 1491.75;
                        }
                        else if (data.resistance <= 11) {
                            if (data.toddlers == null) {
                                return 166.45913;
                            }
                            else if (data.toddlers > 5) {
                                if (data.graduetes == null) {
                                    return 147.30865;
                                }
                                else if (data.graduetes > 36) {
                                    return 262.87208;
                                }
                                else if (data.graduetes <= 36) {
                                    return 117.42155;
                                }
                            }
                            else if (data.toddlers <= 5) {
                                return 865.45157;
                            }
                        }
                    }
                    else if (data.children <= 26) {
                        if (data.graduetes == null) {
                            return 355.96605;
                        }
                        else if (data.graduetes > 30) {
                            if (data.graduetes > 33) {
                                if (data.month > 7) {
                                    if (data.adults == null) {
                                        return 437.01667;
                                    }
                                    else if (data.adults > 12) {
                                        return 657.50833;
                                    }
                                    else if (data.adults <= 12) {
                                        if (data.resistance == null) {
                                            return 363.51944;
                                        }
                                        else if (data.resistance > 9) {
                                            return 167.40625;
                                        }
                                        else if (data.resistance <= 9) {
                                            if (data.gold == null) {
                                                return 438.9476;
                                            }
                                            else if (data.gold > 11) {
                                                return 311.67065;
                                            }
                                            else if (data.gold <= 11) {
                                                return 539.89138;
                                            }
                                        }
                                    }
                                }
                                else if (data.month <= 7) {
                                    return 196.02849;
                                }
                            }
                            else if (data.graduetes <= 33) {
                                if (data.children > 14) {
                                    if (data.resistance == null) {
                                        return 233.05075;
                                    }
                                    else if (data.resistance > 4) {
                                        if (data.gold == null) {
                                            return 211.69961;
                                        }
                                        else if (data.gold > 9) {
                                            if (data.adults == null) {
                                                return 199.18194;
                                            }
                                            else if (data.adults > 10) {
                                                return 173.12074;
                                            }
                                            else if (data.adults <= 10) {
                                                return 378.35274;
                                            }
                                        }
                                        else if (data.gold <= 9) {
                                            return 1000.3125;
                                        }
                                    }
                                    else if (data.resistance <= 4) {
                                        return 688.54167;
                                    }
                                }
                                else if (data.children <= 14) {
                                    return 1290.88125;
                                }
                            }
                        }
                        else if (data.graduetes <= 30) {
                            return 474.27528;
                        }
                    }
                }
                else if (data.month <= 6) {
                    if (data.gold == null) {
                        return 475.65708;
                    }
                    else if (data.gold > 24) {
                        if (data.children > 15) {
                            return 2183.09375;
                        }
                        else if (data.children <= 15) {
                            if (data.children > 12) {
                                return 124.40625;
                            }
                            else if (data.children <= 12) {
                                return 658.95937;
                            }
                        }
                    }
                    else if (data.gold <= 24) {
                        if (data.toddlers == null) {
                            return 459.62574;
                        }
                        else if (data.toddlers > 13) {
                            return 674.71539;
                        }
                        else if (data.toddlers <= 13) {
                            if (data.children > 12) {
                                if (data.children > 19) {
                                    if (data.resistance == null) {
                                        return 462.49962;
                                    }
                                    else if (data.resistance > 3) {
                                        if (data.adults == null) {
                                            return 451.67074;
                                        }
                                        else if (data.adults > 14) {
                                            return 291.05603;
                                        }
                                        else if (data.adults <= 14) {
                                            if (data.adults > 13) {
                                                return 847.81597;
                                            }
                                            else if (data.adults <= 13) {
                                                if (data.gold > 3) {
                                                    if (data.children > 22) {
                                                        if (data.resistance > 5) {
                                                            if (data.size == null) {
                                                                return 354.77268;
                                                            }
                                                            else if (data.size > 4) {
                                                                return 633.80625;
                                                            }
                                                            else if (data.size <= 4) {
                                                                if (data.graduetes == null) {
                                                                    return 324.87623;
                                                                }
                                                                else if (data.graduetes > 40) {
                                                                    return 57.91523;
                                                                }
                                                                else if (data.graduetes <= 40) {
                                                                    if (data.graduetes > 39) {
                                                                        return 1461;
                                                                    }
                                                                    else if (data.graduetes <= 39) {
                                                                        if (data.adults > 8) {
                                                                            return 307.44004;
                                                                        }
                                                                        else if (data.adults <= 8) {
                                                                            return 762.20625;
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        else if (data.resistance <= 5) {
                                                            return 158.95;
                                                        }
                                                    }
                                                    else if (data.children <= 22) {
                                                        if (data.gold > 20) {
                                                            return 56.12812;
                                                        }
                                                        else if (data.gold <= 20) {
                                                            if (data.gold > 17) {
                                                                if (data.gold > 18) {
                                                                    return 501.09141;
                                                                }
                                                                else if (data.gold <= 18) {
                                                                    if (data.graduetes == null) {
                                                                        return 1428.59063;
                                                                    }
                                                                    else if (data.graduetes > 34) {
                                                                        return 391.27969;
                                                                    }
                                                                    else if (data.graduetes <= 34) {
                                                                        return 1947.2461;
                                                                    }
                                                                }
                                                            }
                                                            else if (data.gold <= 17) {
                                                                return 478.49137;
                                                            }
                                                        }
                                                    }
                                                }
                                                else if (data.gold <= 3) {
                                                    return 1403.60625;
                                                }
                                            }
                                        }
                                    }
                                    else if (data.resistance <= 3) {
                                        return 1561.63125;
                                    }
                                }
                                else if (data.children <= 19) {
                                    if (data.graduetes == null) {
                                        return 288.29326;
                                    }
                                    else if (data.graduetes > 29) {
                                        if (data.toddlers > 8) {
                                            return 367.05912;
                                        }
                                        else if (data.toddlers <= 8) {
                                            return 128.50385;
                                        }
                                    }
                                    else if (data.graduetes <= 29) {
                                        return 947.77032;
                                    }
                                }
                            }
                            else if (data.children <= 12) {
                                return 1453.44375;
                            }
                        }
                    }
                }
            }
        }
    }
    else if (data.season <= 1) {
        if (data.weather == null) {
            return 59.58688;
        }
        else if (data.weather > 0) {
            if (data.holiday == null) {
                return 127.20539;
            }
            else if (data.holiday=="0") {
                return 82.7105;
            }
            else if (data.holiday=="1") {
                if (data.size == null) {
                    return 170.55308;
                }
                else if (data.size > 3) {
                    if (data.children == null) {
                        return 289.00616;
                    }
                    else if (data.children > 38) {
                        return 1392.3625;
                    }
                    else if (data.children <= 38) {
                        if (data.adults == null) {
                            return 273.68177;
                        }
                        else if (data.adults > 8) {
                            if (data.graduetes == null) {
                                return 242.86411;
                            }
                            else if (data.graduetes > 34) {
                                return 173.79375;
                            }
                            else if (data.graduetes <= 34) {
                                return 338.5;
                            }
                        }
                        else if (data.adults <= 8) {
                            return 464.75125;
                        }
                    }
                }
                else if (data.size <= 3) {
                    if (data.resistance == null) {
                        return 152.15505;
                    }
                    else if (data.resistance > 8) {
                        if (data.graduetes == null) {
                            return 186.507;
                        }
                        else if (data.graduetes > 25) {
                            if (data.graduetes > 40) {
                                return 326.70441;
                            }
                            else if (data.graduetes <= 40) {
                                return 163.38008;
                            }
                        }
                        else if (data.graduetes <= 25) {
                            return 902.8;
                        }
                    }
                    else if (data.resistance <= 8) {
                        return 130.0545;
                    }
                }
            }
        }
        else if (data.weather <= 0) {
            return 9.24866;
        }
    }
    return null;
}