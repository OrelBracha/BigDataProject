import redis from 'redis';
import fetch from 'node-fetch';
import express from 'express';

const USER_NAME = 'username';
const PORT = 5000;
const REDIS_PORT = 6379;
/*
const client = redis.createClient({
    socket: {
      host: "127.0.0.1",
      port: REDIS_PORT
    }
  });
  */
const client = redis.createClient(REDIS_PORT);
client.on('connect', function() {
    console.log('Connected!');
});
client.connect();
/*
const app = express();

function formatOutput(username, numOfRepos)
{
    return `${username} has ${numOfRepos} repos`;
}

async function getRepos(req, res)
{
try
{
  const username = req.params[USER_NAME];

  const response = await fetch(`https://api.github.com/users/${username}`);

  const { public_repos } = await response.json();
  
  client.set(username, public_repos);

  res.send(formatOutput(username, public_repos));
} catch(err){
  console.error(err);
  res.status(500);
}

}
function cache(req, res, next)
{
    const username = req.params[USER_NAME];

    client.get(username, (err,data) => {
        if(err) throw err;

        if(data != null)
        {
             res.send(formatOutput(username, data));
        } else {
            next();
        }

    });
}

app.get(`/repos/:${USER_NAME}`, cache, getRepos);

app.listen(PORT, ()=> {
    console.log(`App listening on port ${PORT}`);

});
*/
client.set("ChannelName","CodeSpace", console.log(redis.print));
client.get("ChannelName", console.log(redis.print));