// Set new default font family and font color to mimic Bootstrap's default styling
Chart.defaults.global.defaultFontFamily = 'Nunito', '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
Chart.defaults.global.defaultFontColor = '#858796';

// Pie Chart Example
var ctx = document.getElementById("myPieChart");
var myPieChart = new Chart(ctx, {
  type: 'doughnut',
  data: {
    labels: ["Lemon", "Vanilla", "Strawberry", "Halva", "Chocolate"],
    datasets: [{
      data: [17.4, 46.4, 17.4, 1.4, 17.4],
      backgroundColor: ['#ffff00', '#f6c23e', '#4e73df', '#e74a3b', '#1cc88a'],
      hoverBackgroundColor: ['#ffff00', '#f6c23e', '#4e73df', '#e74a3b', '#1cc88a'],
      hoverBorderColor: "rgba(234, 236, 244, 1)",
    }],
  },
  options: {
    maintainAspectRatio: false,
    tooltips: {
      backgroundColor: "rgb(255,255,255)",
      bodyFontColor: "#858796",
      borderColor: '#dddfeb',
      borderWidth: 1,
      xPadding: 15,
      yPadding: 15,
      displayColors: false,
      caretPadding: 10,
    },
    legend: {
      display: false
    },
    cutoutPercentage: 80,
  },
});




var theseason = document.getElementById("theseason");
function getCurrentSeason() {
  // It's plus one because January is index 0
  const now = new Date();
  const month = now.getMonth() + 1;

  if (month > 3 && month < 6) {
    return 'spring';
  }

  if (month > 6 && month < 9) {
    return 'summer';
  }

  if (month > 9 && month < 12) {
    return 'fall';
  }

  if (month >= 1 && month < 3) {
    return 'winter';
  }

  const day = now.getDate();
  if (month === 3) {
    return day < 22 ? 'winter' : 'spring';
  }

  if (month === 6) {
    return day < 22 ? 'spring' : 'summer';
  }

  if (month === 9) {
    return day < 22 ? 'summer' : 'fall';
  }

  if (month === 12) {
    return day < 22 ? 'fall' : 'winter';
  }

}

theseason.textContent = getCurrentSeason();